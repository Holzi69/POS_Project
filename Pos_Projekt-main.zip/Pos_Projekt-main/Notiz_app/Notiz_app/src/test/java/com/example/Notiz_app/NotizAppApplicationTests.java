package com.example.Notiz_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotizAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

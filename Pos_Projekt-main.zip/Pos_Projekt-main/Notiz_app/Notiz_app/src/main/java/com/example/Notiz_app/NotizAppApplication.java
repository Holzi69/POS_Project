package com.example.Notiz_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotizAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotizAppApplication.class, args);
	}

}
